#
# Python Training Day 1: Assignment 1
#
name = 'B.M. ASHIK MAHMUD'
empID = 96194899
designation = 'Jr System Analyst'
address = 'Gulshan-2'
print('Name: '+name+'\n'+'Employee ID: '+
      str(empID)+'\n'+
      'Designamtion: '+designation+'\n'+
      'Address: '+address+'\n'
      )
print(type(name))
print(type(empID))